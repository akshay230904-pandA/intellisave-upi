from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.conf import settings
import pandas as pd
import os
import json
from .utils import UPICategorizer, generate_sample_data
from .models import Transaction, AnalysisResult, SavingsSuggestion, Budget
from datetime import datetime

def index(request):
    return render(request, 'index.html')


#@login_required
def upload_file(request):
    if request.method == 'POST' and request.FILES.get('file'):
        uploaded_file = request.FILES['file']
        
        # Check if file is CSV
        if not uploaded_file.name.endswith('.csv'):
            messages.error(request, 'Please upload a CSV file........')
            return redirect('index')
        
        file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', uploaded_file.name)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        try:
            # Save the uploaded file
            with open(file_path, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Check if CSV has required columns
            required_columns = ['Date', 'Description', 'Amount', 'Transaction Type']
            if not all(col in df.columns for col in required_columns):
                messages.error(request, 'CSV file must contain these columns: Date, Description, Amount, Transaction Type')
                return redirect('index')
            
            # Get user budgets
            user_budgets = {}
            budgets = Budget.objects.filter(user=request.user)
            for budget in budgets:
                user_budgets[budget.category] = float(budget.monthly_limit)
            
            # Categorize transactions
            categorizer = UPICategorizer()
            categorizer.train_model(df)
            df_categorized = categorizer.categorize_transactions(df)
            
            # Save transactions to database
            for _, row in df_categorized.iterrows():
                Transaction.objects.create(
                    user=request.user,
                    date=datetime.strptime(row['Date'], '%Y-%m-%d').date(),
                    description=row['Description'],
                    amount=row['Amount'],
                    transaction_type=row['Transaction Type'],
                    category=row['Category']
                )
            
            # Analyze spending
            analysis_results = categorizer.analyze_spending(df_categorized, user_budgets)
            filename_prefix = f"{request.user.username}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            analysis_image_path, trends_image_path = categorizer.visualize_spending(
                df_categorized, 
                analysis_results,
                filename_prefix
            )
            
            # Save analysis results
            analysis = AnalysisResult.objects.create(
                user=request.user,
                total_spent=analysis_results['total_expenses'],
                total_income=analysis_results['total_income'],
                savings_rate=analysis_results['savings_rate'],
                max_spending_category=analysis_results['max_spending_category'],
                max_spending_amount=analysis_results['max_spending_amount'],
                max_spending_percentage=analysis_results['max_spending_percentage'],
                visualization=analysis_image_path,
                monthly_trends=trends_image_path
            )
            
            # Save suggestions
            for suggestion in analysis_results['suggestions']:
                SavingsSuggestion.objects.create(
                    analysis=analysis,
                    suggestion_text=suggestion['text'],
                    priority=suggestion['priority'],
                    potential_savings=suggestion.get('potential_savings', None)
                )
            
            total_potential_savings = sum([
                s.potential_savings for s in analysis.suggestions.all() 
                if s.potential_savings is not None
            ])
            
            # Prepare context for results page
            context = {
                'transactions': Transaction.objects.filter(user=request.user).order_by('-date')[:20],
                'analysis': analysis,
                'suggestions': analysis.suggestions.all().order_by('priority'),
                'total_spent': analysis_results['total_expenses'],
                'total_income': analysis_results['total_income'],
                'savings_rate': analysis_results['savings_rate'],
                'budget_alerts': analysis_results['budget_alerts'],
                'max_spending_category': analysis_results['max_spending_category'],
                'max_spending_amount': analysis_results['max_spending_amount'],
                'max_spending_percentage': analysis_results['max_spending_percentage'],
                'visualization_url': analysis.visualization.url if analysis.visualization else None,
                'trends_url': analysis.monthly_trends.url if analysis.monthly_trends else None,
                'total_potential_savings': total_potential_savings
            }
            
            return render(request, 'results.html', context)
        
        except Exception as e:
            messages.error(request, f'Error processing file: {str(e)}')
            return redirect('index')
    
    messages.error(request, 'Please upload a valid CSV file.')
    return redirect('index')
#login_required
def demo(request):
    try:
        df = generate_sample_data(100)
        categorizer = UPICategorizer()
        categorizer.train_model(df)
        df_categorized = categorizer.categorize_transactions(df)
        analysis_results = categorizer.analyze_spending(df_categorized)
        
        filename_prefix = f"demo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        analysis_image_path, trends_image_path = categorizer.visualize_spending(
            df_categorized, 
            analysis_results,
            filename_prefix
        )
        
        total_potential_savings = sum([
            s.get('potential_savings', 0) for s in analysis_results['suggestions']
        ])
        
        context = {
            'transactions': df_categorized.head(20).to_dict('records'),
            'total_spent': analysis_results['total_expenses'],
            'total_income': analysis_results['total_income'],
            'savings_rate': analysis_results['savings_rate'],
            'suggestions': analysis_results['suggestions'],
            'max_spending_category': analysis_results['max_spending_category'],
            'max_spending_amount': analysis_results['max_spending_amount'],
            'max_spending_percentage': analysis_results['max_spending_percentage'],
            'visualization_url': f"/media/{analysis_image_path}",
            'trends_url': f"/media/{trends_image_path}" if trends_image_path else None,
            'is_demo': True,
            'total_potential_savings': total_potential_savings
        }
        
        return render(request, 'results.html', context)
    
    except Exception as e:
        messages.error(request, f'Error in demo: {str(e)}')
        return redirect('index')

#@login_required
def history(request):
    analyses = AnalysisResult.objects.filter(user=request.user).order_by('-analysis_date')
    return render(request, 'history.html', {'analyses': analyses})

#@login_required
def analysis_detail(request, analysis_id):
    analysis = get_object_or_404(AnalysisResult, id=analysis_id, user=request.user)
    suggestions = analysis.suggestions.all().order_by('priority')
    
    total_potential_savings = sum([
        s.potential_savings for s in suggestions 
        if s.potential_savings is not None
    ])
    
    context = {
        'analysis': analysis,
        'suggestions': suggestions,
        'visualization_url': analysis.visualization.url if analysis.visualization else None,
        'trends_url': analysis.monthly_trends.url if analysis.monthly_trends else None,
        'total_potential_savings': total_potential_savings
    }
    
    return render(request, 'analysis_detail.html', context)

#@login_required
def set_budget(request):
    if request.method == 'POST':
        category = request.POST.get('category')
        monthly_limit = request.POST.get('monthly_limit')
        
        if category and monthly_limit:
            try:
                budget, created = Budget.objects.update_or_create(
                    user=request.user,
                    category=category,
                    defaults={'monthly_limit': monthly_limit}
                )
                
                if created:
                    messages.success(request, f'Budget for {category} set to ₹{monthly_limit}')
                else:
                    messages.success(request, f'Budget for {category} updated to ₹{monthly_limit}')
            except ValueError:
                messages.error(request, 'Please enter a valid number for the budget limit.')
        
        return redirect('budgets')
    
    return redirect('index')

#@login_required
def budgets(request):
    budgets = Budget.objects.filter(user=request.user)
    categories = [choice[0] for choice in Transaction.CATEGORY_CHOICES]
    
    context = {
        'budgets': budgets,
        'categories': categories
    }
    
    return render(request, 'budgets.html', context)

#@login_required
def delete_budget(request, budget_id):
    budget = get_object_or_404(Budget, id=budget_id, user=request.user)
    budget.delete()
    messages.success(request, f'Budget for {budget.category} deleted successfully.')
    return redirect('budgets')