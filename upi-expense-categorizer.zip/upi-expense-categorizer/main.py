import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import re
import random
import os
import sys
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import warnings
warnings.filterwarnings('ignore')

# Download NLTK data
try:
    nltk.download('stopwords')
except:
    pass

class UPICategorizer:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.model = MultinomialNB()
        self.categories = {
            'Food': ['zomato', 'swiggy', 'restaurant', 'cafe', 'food', 'pizza', 'burger', 
                    'mcdonalds', 'kfc', 'dominos', 'eating', 'dining', 'coffee'],
            'Shopping': ['amazon', 'flipkart', 'myntra', 'shopping', 'store', 'market', 
                        'fashion', 'ajio', 'clothing', 'apparel', 'purchase', 'buy'],
            'Transport': ['uber', 'ola', 'rapido', 'metro', 'bus', 'train', 'fuel', 
                         'petrol', 'diesel', 'taxi', 'auto', 'ride', 'travel'],
            'Entertainment': ['netflix', 'hotstar', 'prime', 'movie', 'cinema', 'theater', 
                             'concert', 'event', 'ticket', 'streaming', 'subscription'],
            'Utilities': ['electricity', 'water', 'gas', 'bill', 'recharge', 'phone', 
                         'internet', 'broadband', 'mobile', 'postpaid', 'prepaid'],
            'Healthcare': ['hospital', 'clinic', 'pharmacy', 'med', 'doctor', 'apollo', 
                          'medplus', 'health', 'medical', 'medicine', 'drug'],
            'Travel': ['makemytrip', 'goibibo', 'booking', 'hotel', 'flight', 'travel', 
                      'trip', 'vacation', 'holiday', 'resort', 'airbnb'],
            'Education': ['book', 'course', 'university', 'college', 'school', 'training', 
                         'tuition', 'fee', 'education', 'learning', 'workshop'],
            'Transfer': ['transfer', 'sent', 'received', 'friend', 'family', 'account', 
                        'self', 'own', 'bank', 'upi', 'pay'],
            'Other': ['other', 'misc', 'unknown', 'miscellaneous']
        }
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        self.is_trained = False
    
    def preprocess_text(self, text):
        if pd.isna(text):
            return ""
        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        tokens = text.split()
        tokens = [token for token in tokens if token not in self.stop_words]
        tokens = [self.stemmer.stem(token) for token in tokens]
        return ' '.join(tokens)
    
    def categorize_based_on_rules(self, description):
        description = description.lower()
        for category, keywords in self.categories.items():
            for keyword in keywords:
                if keyword in description:
                    return category
        return 'Other'
    
    def prepare_training_data(self, df):
        df_train = df.copy()
        df_train['Category'] = df_train['Description'].apply(self.categorize_based_on_rules)
        return df_train
    
    def train_model(self, df):
        df_train = self.prepare_training_data(df)
        df_train['Processed_Text'] = df_train['Description'].apply(self.preprocess_text)
        X = df_train['Processed_Text']
        y = df_train['Category']
        X_vec = self.vectorizer.fit_transform(X)
        self.model.fit(X_vec, y)
        self.is_trained = True
        X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        print(f"Model trained with accuracy: {accuracy_score(y_test, y_pred):.2f}")
        return accuracy_score(y_test, y_pred)
    
    def categorize_transactions(self, df):
        if not self.is_trained:
            df['Category'] = df['Description'].apply(self.categorize_based_on_rules)
            return df
        df['Processed_Text'] = df['Description'].apply(self.preprocess_text)
        X_vec = self.vectorizer.transform(df['Processed_Text'])
        df['Category'] = self.model.predict(X_vec)
        return df
    
    def analyze_spending(self, df):
        df['Date'] = pd.to_datetime(df['Date'])
        expenses_df = df[df['Transaction Type'] == 'Debit'].copy()
        income_df = df[df['Transaction Type'] == 'Credit'].copy()
        expenses_df['Month'] = expenses_df['Date'].dt.to_period('M')
        expenses_df['Year'] = expenses_df['Date'].dt.year
        
        category_spending = expenses_df.groupby('Category')['Amount'].sum().sort_values(ascending=False)
        monthly_spending = expenses_df.groupby('Month')['Amount'].sum()
        monthly_category_spending = expenses_df.groupby(['Month', 'Category'])['Amount'].sum().unstack(fill_value=0)
        avg_category_spending = expenses_df.groupby('Category')['Amount'].mean().sort_values(ascending=False)
        
        total_income = income_df['Amount'].sum() if not income_df.empty else 0
        total_expenses = expenses_df['Amount'].sum() if not expenses_df.empty else 0
        savings_rate = ((total_income - total_expenses) / total_income * 100) if total_income > 0 else 0
        
        top_categories = category_spending.head(5)
        max_spending_category = category_spending.idxmax() if not category_spending.empty else 'None'
        max_spending_amount = category_spending.max() if not category_spending.empty else 0
        max_spending_percentage = (max_spending_amount / total_expenses * 100) if total_expenses > 0 else 0
        
        suggestions = self.generate_savings_suggestions(
            expenses_df, 
            category_spending, 
            total_income,
            max_spending_category,
            max_spending_amount,
            max_spending_percentage
        )
        
        return {
            'category_spending': category_spending,
            'monthly_spending': monthly_spending,
            'monthly_category_spending': monthly_category_spending,
            'avg_category_spending': avg_category_spending,
            'top_categories': top_categories,
            'total_income': total_income,
            'total_expenses': total_expenses,
            'savings_rate': savings_rate,
            'max_spending_category': max_spending_category,
            'max_spending_amount': max_spending_amount,
            'max_spending_percentage': max_spending_percentage,
            'suggestions': suggestions
        }
    
    def generate_savings_suggestions(self, expenses_df, category_spending, total_income, 
                                   max_spending_category, max_spending_amount, max_spending_percentage):
        suggestions = []
        total_spending = category_spending.sum()
        
        for category, amount in category_spending.items():
            percentage = (amount / total_spending) * 100
            if percentage > 20:
                if category == 'Food':
                    suggestions.append({
                        'text': f"Your spending on Food is {percentage:.1f}% of your total expenses. Consider meal planning and cooking at home more often.",
                        'priority': 1,
                        'potential_savings': amount * 0.15
                    })
                elif category == 'Transport':
                    suggestions.append({
                        'text': f"Your spending on Transport is {percentage:.1f}% of your total expenses. Consider using public transportation or carpooling.",
                        'priority': 1,
                        'potential_savings': amount * 0.20
                    })
                elif category == 'Entertainment':
                    suggestions.append({
                        'text': f"Your spending on Entertainment is {percentage:.1f}% of your total expenses. Look for free or low-cost entertainment options.",
                        'priority': 2,
                        'potential_savings': amount * 0.25
                    })
                else:
                    suggestions.append({
                        'text': f"Your spending on {category} is {percentage:.1f}% of your total expenses. Consider setting a budget for this category.",
                        'priority': 2,
                        'potential_savings': amount * 0.10
                    })
        
        frequent_categories = expenses_df['Category'].value_counts()
        for category, count in frequent_categories.items():
            if count > 10:
                avg_amount = expenses_df[expenses_df['Category'] == category]['Amount'].mean()
                if avg_amount < 500:
                    total_category_spending = category_spending.get(category, 0)
                    suggestions.append({
                        'text': f"You make frequent small purchases in {category} ({count} transactions). These small expenses add up to ₹{total_category_spending:.2f}.",
                        'priority': 2,
                        'potential_savings': total_category_spending * 0.30
                    })
        
        subscription_keywords = ['subscription', 'netflix', 'prime', 'hotstar', 'spotify', 'renewal']
        subscription_expenses = expenses_df[
            expenses_df['Description'].str.lower().str.contains('|'.join(subscription_keywords))
        ]
        if not subscription_expenses.empty:
            total_subscriptions = subscription_expenses['Amount'].sum()
            suggestions.append({
                'text': f"You spend ₹{total_subscriptions:.2f} on subscriptions. Review your subscriptions and cancel any you don't use regularly.",
                'priority': 1,
                'potential_savings': total_subscriptions * 0.50
            })
        
        if max_spending_category != 'None':
            suggestions.append({
                'text': f"You spent the most on {max_spending_category} (₹{max_spending_amount:.2f}), which is {max_spending_percentage:.1f}% of your total expenses.",
                'priority': 1,
                'potential_savings': max_spending_amount * 0.15
            })
        
        savings_rate = ((total_income - total_spending) / total_income * 100) if total_income > 0 else 0
        if savings_rate < 20:
            suggestions.append({
                'text': f"Your savings rate is {savings_rate:.1f}%, which is below the recommended 20%. Try to increase your savings by reducing discretionary spending.",
                'priority': 1,
                'potential_savings': total_spending * 0.05
            })
        
        for category, amount in category_spending.items():
            if amount > 1000:
                for reduction in [10, 20, 30]:
                    potential_saving = amount * (reduction / 100)
                    suggestions.append({
                        'text': f"If you reduced your {category} spending by {reduction}%, you could save ₹{potential_saving:.2f} per month.",
                        'priority': 3,
                        'potential_savings': potential_saving
                    })
        
        if not suggestions:
            suggestions.append({
                'text': "Your spending patterns look balanced. Consider setting aside 20% of your income for savings.",
                'priority': 3,
                'potential_savings': total_spending * 0.05
            })
        else:
            suggestions.append({
                'text': "Consider using the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings.",
                'priority': 3,
                'potential_savings': total_spending * 0.05
            })
        
        return suggestions
    
    def visualize_spending(self, df, analysis_results, filename_prefix=''):
        sns.set_style("whitegrid")
        os.makedirs('analysis_images', exist_ok=True)
        os.makedirs('trends_images', exist_ok=True)
        
        plt.figure(figsize=(15, 10))
        plt.subplot(2, 2, 1)
        category_spending = analysis_results['category_spending']
        plt.pie(category_spending.values, labels=category_spending.index, autopct='%1.1f%%')
        plt.title('Spending by Category')
        
        plt.subplot(2, 2, 2)
        monthly_spending = analysis_results['monthly_spending']
        monthly_spending.plot(kind='line', marker='o')
        plt.title('Monthly Spending Trend')
        plt.xlabel('Month')
        plt.ylabel('Amount (₹)')
        plt.xticks(rotation=45)
        
        plt.subplot(2, 2, 3)
        avg_spending = analysis_results['avg_category_spending']
        avg_spending.plot(kind='bar')
        plt.title('Average Spending by Category')
        plt.xlabel('Category')
        plt.ylabel('Average Amount (₹)')
        plt.xticks(rotation=45)
        
        plt.subplot(2, 2, 4)
        top_categories = analysis_results['top_categories']
        top_categories.plot(kind='bar', color='red')
        plt.title('Top Spending Categories')
        plt.xlabel('Category')
        plt.ylabel('Total Amount (₹)')
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        analysis_image_path = f"analysis_images/{filename_prefix}_analysis.png"
        plt.savefig(analysis_image_path)
        plt.close()
        
        if not analysis_results['monthly_category_spending'].empty:
            plt.figure(figsize=(12, 8))
            monthly_category_spending = analysis_results['monthly_category_spending']
            monthly_category_spending.plot(kind='line', marker='o', figsize=(12, 8))
            plt.title('Monthly Spending Trends by Category')
            plt.xlabel('Month')
            plt.ylabel('Amount (₹)')
            plt.xticks(rotation=45)
            plt.legend(title='Category', bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.tight_layout()
            
            trends_image_path = f"trends_images/{filename_prefix}_trends.png"
            plt.savefig(trends_image_path)
            plt.close()
            
            trends_image_url = trends_image_path
        else:
            trends_image_url = None
        
        return analysis_image_path, trends_image_url

def generate_sample_data(num_records=500):
    categories = {
        'Food': ['zomato', 'swiggy', 'restaurant', 'cafe', 'food', 'pizza', 'burger', 'mcdonalds', 'kfc'],
        'Shopping': ['amazon', 'flipkart', 'myntra', 'shopping', 'store', 'market', 'fashion'],
        'Transport': ['uber', 'ola', 'rapido', 'metro', 'bus', 'train', 'fuel', 'petrol', 'diesel'],
        'Entertainment': ['netflix', 'hotstar', 'prime', 'movie', 'cinema', 'theater', 'concert'],
        'Utilities': ['electricity', 'water', 'gas', 'bill', 'recharge', 'phone', 'internet'],
        'Healthcare': ['hospital', 'clinic', 'pharmacy', 'med', 'doctor', 'apollo'],
        'Travel': ['makemytrip', 'goibibo', 'booking', 'hotel', 'flight', 'travel'],
        'Education': ['book', 'course', 'university', 'college', 'school', 'training'],
        'Transfer': ['transfer', 'sent', 'received', 'friend', 'family'],
        'Other': ['other', 'misc', 'unknown']
    }
    
    remarks_templates = [
        "UPI payment to {merchant}",
        "Transfer to {name}",
        "Payment for {service}",
        "Received from {name}",
        "Bill payment to {company}",
        "Recharge for {service}",
        "Shopping at {store}",
        "Food order from {restaurant}",
        "Subscription for {service}",
        "Cashback from {app}"
    ]
    
    merchants = [
        "Zomato", "Swiggy", "Amazon", "Flipkart", "Myntra", "Uber", "Ola", 
        "Netflix", "Hotstar", "Prime", "BookMyShow", "MakeMyTrip", "GoIbibo",
        "Apollo Pharmacy", "MedPlus", "Reliance Fresh", "Big Bazaar", "DMart",
        "Indian Oil", "HP Petrol", "BSNL", "Airtel", "Jio", "Vi", "Electricity Board",
        "Water Works", "Gas Agency", "Apple Store", "Google Play", "Spotify"
    ]
    
    names = ["Rahul", "Priya", "Amit", "Sneha", "Raj", "Anjali", "Vikram", "Neha", 
             "Karan", "Divya", "Arjun", "Pooja", "Sanjay", "Meera", "Vivek"]
    
    data = []
    start_date = datetime(2024, 1, 1)
    
    for i in range(num_records):
        date = start_date + timedelta(days=random.randint(0, 365))
        is_income = random.random() < 0.2
        amount = round(random.uniform(50, 10000), 2)
        if is_income:
            amount = -amount
        
        transaction_type = "Credit" if amount < 0 else "Debit"
        category = random.choice(list(categories.keys()))
        
        template = random.choice(remarks_templates)
        if "{merchant}" in template:
            remark = template.format(merchant=random.choice(merchants))
        elif "{name}" in template:
            remark = template.format(name=random.choice(names))
        elif "{service}" in template:
            remark = template.format(service=random.choice(merchants))
        elif "{company}" in template:
            remark = template.format(company=random.choice(merchants))
        elif "{store}" in template:
            remark = template.format(store=random.choice(merchants))
        elif "{restaurant}" in template:
            remark = template.format(restaurant=random.choice(merchants))
        elif "{app}" in template:
            remark = template.format(app=random.choice(["Google Pay", "PhonePe", "Paytm"]))
        else:
            remark = template
        
        if category != "Other":
            keyword = random.choice(categories[category])
            remark = f"{remark} {keyword}"
        
        data.append({
            "Date": date.strftime("%Y-%m-%d"),
            "Description": remark,
            "Amount": abs(amount),
            "Transaction Type": transaction_type,
            "Category": "Unknown"
        })
    
    return pd.DataFrame(data)

def display_results(df_categorized, analysis_results, analysis_image_path, trends_image_path):
    print("\n" + "="*80)
    print("INTELLISAVE AI: UPI EXPENSE CATEGORIZER")
    print("="*80)
    
    print("\nFINANCIAL SUMMARY:")
    print("-" * 40)
    print(f"Total Income: ₹{analysis_results['total_income']:.2f}")
    print(f"Total Expenses: ₹{analysis_results['total_expenses']:.2f}")
    print(f"Savings Rate: {analysis_results['savings_rate']:.2f}%")
    print(f"Maximum Spending Category: {analysis_results['max_spending_category']} "
          f"(₹{analysis_results['max_spending_amount']:.2f}, {analysis_results['max_spending_percentage']:.2f}%)")
    
    print("\nCATEGORY-WISE SPENDING:")
    print("-" * 40)
    for category, amount in analysis_results['category_spending'].items():
        percentage = (amount / analysis_results['total_expenses'] * 100) if analysis_results['total_expenses'] > 0 else 0
        print(f"{category}: ₹{amount:.2f} ({percentage:.2f}%)")
    
    print("\nPERSONALIZED SAVINGS SUGGESTIONS:")
    print("-" * 40)
    total_potential_savings = 0
    for i, suggestion in enumerate(analysis_results['suggestions'], 1):
        print(f"{i}. {suggestion['text']}")
        if 'potential_savings' in suggestion:
            total_potential_savings += suggestion['potential_savings']
    
    print(f"\nTotal Potential Savings: ₹{total_potential_savings:.2f}")
    
    print("\nRECENT TRANSACTIONS:")
    print("-" * 40)
    print(df_categorized[['Date', 'Description', 'Amount', 'Category']].head(10).to_string(index=False))
    
    print(f"\nVisualizations saved to:")
    print(f"- Analysis: {analysis_image_path}")
    if trends_image_path:
        print(f"- Trends: {trends_image_path}")

def main():
    print("Welcome to Intellisave AI: UPI Expense Categorizer!")
    print("This tool will automatically categorize your UPI transactions and provide insights.")
    
    while True:
        print("\nOptions:")
        print("1. Upload your UPI transaction CSV file")
        print("2. Try with sample data")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            file_path = input("Enter the path to your CSV file: ").strip()
            if not os.path.exists(file_path):
                print("File not found. Please check the path and try again.")
                continue
            
            try:
                df = pd.read_csv(file_path)
                print("File loaded successfully!")
            except Exception as e:
                print(f"Error reading file: {e}")
                continue
            
        elif choice == '2':
            num_records = input("How many sample transactions would you like? (default: 100): ").strip()
            if not num_records:
                num_records = 100
            else:
                try:
                    num_records = int(num_records)
                except:
                    num_records = 100
            
            df = generate_sample_data(num_records)
            print(f"Generated {num_records} sample transactions!")
            
        elif choice == '3':
            print("Thank you for using Intellisave AI!")
            break
        
        else:
            print("Invalid choice. Please try again.")
            continue
        
        # Process the data
        categorizer = UPICategorizer()
        categorizer.train_model(df)
        df_categorized = categorizer.categorize_transactions(df)
        
        # Save categorized data
        df_categorized.to_csv('categorized_transactions.csv', index=False)
        print("Categorized data saved to 'categorized_transactions.csv'")
        
        # Analyze spending
        analysis_results = categorizer.analyze_spending(df_categorized)
        
        # Create visualizations
        filename_prefix = f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        analysis_image_path, trends_image_path = categorizer.visualize_spending(df_categorized, analysis_results, filename_prefix)
        
        # Display results
        display_results(df_categorized, analysis_results, analysis_image_path, trends_image_path)
        
        # Ask if user wants to continue
        continue_choice = input("\nWould you like to analyze another file? (y/n): ").strip().lower()
        if continue_choice != 'y':
            print("Thank you for using Intellisave AI!")
            break

if __name__ == "__main__":
    main()