from django.contrib import admin
from .models import Transaction, Budget, AnalysisResult, SavingsSuggestion

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'description', 'amount', 'category')
    list_filter = ('category', 'transaction_type', 'date')
    search_fields = ('description', 'user__username')

@admin.register(Budget)
class BudgetAdmin(admin.ModelAdmin):
    list_display = ('user', 'category', 'monthly_limit')
    list_filter = ('category',)
    search_fields = ('user__username',)

@admin.register(AnalysisResult)
class AnalysisResultAdmin(admin.ModelAdmin):
    list_display = ('user', 'analysis_date', 'total_spent', 'total_income', 'savings_rate')
    list_filter = ('analysis_date',)
    search_fields = ('user__username',)

@admin.register(SavingsSuggestion)
class SavingsSuggestionAdmin(admin.ModelAdmin):
    list_display = ('analysis', 'priority', 'suggestion_text')
    list_filter = ('priority',)
    search_fields = ('suggestion_text',)