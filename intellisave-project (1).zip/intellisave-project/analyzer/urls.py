from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.upload_file, name='upload'),
    path('demo/', views.demo, name='demo'),
    path('history/', views.history, name='history'),
    path('analysis/<int:analysis_id>/', views.analysis_detail, name='analysis_detail'),
    path('budgets/', views.budgets, name='budgets'),
    path('set_budget/', views.set_budget, name='set_budget'),
    path('delete_budget/<int:budget_id>/', views.delete_budget, name='delete_budget'),
]