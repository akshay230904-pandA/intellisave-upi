from django.db import models
from django.contrib.auth.models import User

class Transaction(models.Model):
    CATEGORY_CHOICES = [
        ('Food', 'Food'),
        ('Shopping', 'Shopping'),
        ('Transport', 'Transport'),
        ('Entertainment', 'Entertainment'),
        ('Utilities', 'Utilities'),
        ('Healthcare', 'Healthcare'),
        ('Travel', 'Travel'),
        ('Education', 'Education'),
        ('Transfer', 'Transfer'),
        ('Other', 'Other'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateField()
    description = models.TextField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(max_length=10, choices=[('Debit', 'Debit'), ('Credit', 'Credit')])
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='Other')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.date} - {self.description} - ₹{self.amount}"

class Budget(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.CharField(max_length=20, choices=Transaction.CATEGORY_CHOICES)
    monthly_limit = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['user', 'category']
    
    def __str__(self):
        return f"{self.user.username} - {self.category} - ₹{self.monthly_limit}"

class AnalysisResult(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    analysis_date = models.DateTimeField(auto_now_add=True)
    total_spent = models.DecimalField(max_digits=12, decimal_places=2)
    total_income = models.DecimalField(max_digits=12, decimal_places=2)
    savings_rate = models.DecimalField(max_digits=5, decimal_places=2)
    max_spending_category = models.CharField(max_length=20, default='')
    max_spending_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    max_spending_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    visualization = models.ImageField(upload_to='analysis_images/', null=True, blank=True)
    monthly_trends = models.ImageField(upload_to='trends_images/', null=True, blank=True)
    
    def __str__(self):
        return f"Analysis on {self.analysis_date}"

class SavingsSuggestion(models.Model):
    PRIORITY_CHOICES = [
        (1, 'High'),
        (2, 'Medium'),
        (3, 'Low'),
    ]
    
    analysis = models.ForeignKey(AnalysisResult, on_delete=models.CASCADE, related_name='suggestions')
    suggestion_text = models.TextField()
    priority = models.IntegerField(choices=PRIORITY_CHOICES, default=2)
    potential_savings = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    class Meta:
        ordering = ['priority']
    
    def __str__(self):
        return f"Suggestion #{self.priority}: {self.suggestion_text[:50]}..."
    